---
name: "Documentation"
about: "Found a typo or something that needs clarification?"
---


**Motivation**

Why should we update our docs?

What should we do instead?

**Suggestion**

What should we do instead?

**Fix**

Did you find a typo/mistake?