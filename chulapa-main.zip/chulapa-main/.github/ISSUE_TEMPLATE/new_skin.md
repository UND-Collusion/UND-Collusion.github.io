---
name: Add your skin
about: Share your awesome skiin
title: ''
labels: ''
assignees: ''
---

**Name of the skin**
How should we name it?

**Author details**
In order to provide attribution, please share your name and personal site. If you prefer no to do so, your Github profile would be used.

**Live preview**
Share a link with a live implementation of the theme.
