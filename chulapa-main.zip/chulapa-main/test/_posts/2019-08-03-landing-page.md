---
layout: landingpage
title: A landing page
subtitle: With image header
header_type: image
header_img: "https://dieghernan.github.io/chulapa/assets/img/site/transparent.png"
categories: [landing-page]
tags: [example, demo,layout, guest-author]
author:
  name: Octocat
  avatar: https://github.com/octocat.png
  location: Pennsylvania, United States
  links:                
    - url: https://github.com/github/
      icon: "fab fa-github"
    - url: https://twitter.com/github
      icon: fab fa-twitter
    - url: https://github.com/facebook
      icon: "fab fa-facebook"
    - url: https://www.linkedin.com
      icon: "fab fa-linkedin"
---

A simple landing page with an image on top. Transparencies (`png`) works better on this combination.