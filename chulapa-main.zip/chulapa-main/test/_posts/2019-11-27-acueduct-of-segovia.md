---
title: "The Acueduct of Segovia"
subtitle: "20 centuries ago"
header_type: splash
header_img: "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d7/Acueducto_Segovia_noche.JPG/1024px-Acueducto_Segovia_noche.JPG"
categories: [picture]
tags: [landscape, trips, downtown, project-links]
project_links:
  - url: https://en.wikipedia.org/wiki/Aqueduct_of_Segovia
    icon: "fab fa-wikipedia-w"
    label: See on Wikipedia
author:
  location: "Acueducto de Segovia, Spain"
---

The **Aqueduct of Segovia** (Spanish: *Acueducto de Segovia*; more accurately, the aqueduct bridge) is a Roman aqueduct in Segovia, Spain. It is one of the best-preserved elevated Roman aqueducts and the foremost symbol of Segovia, as evidenced by its presence on the city's coat of arms.