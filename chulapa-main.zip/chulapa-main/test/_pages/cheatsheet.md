---
layout: indexcategory
title: "Cheatsheets"
include_collection: cheatsheet
permalink: /cheatsheets
show_breadcrumb: true
---

If it is first time using `markdown` and `jekyll`, you may find this pages useful.