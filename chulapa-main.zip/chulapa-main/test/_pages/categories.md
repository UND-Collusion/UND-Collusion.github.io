---
layout: cloudcategory
title: Categories
permalink: /categories
excerpt: Categories on this theme
show_breadcrumb   : true
---