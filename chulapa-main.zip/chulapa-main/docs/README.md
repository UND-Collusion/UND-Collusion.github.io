# Chulapa website

This folder contains the source code of the webpage <https://dieghernan.github.io/chulapa/>.

If you are looking for the source code of the Jekyll theme Chulapa, you can find it on <https://github.com/dieghernan/chulapa>