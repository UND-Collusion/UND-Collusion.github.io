---
layout: indexcategory
title: '<span class="chulapa">Chulapa</span> Demos'
subtitle: All demos in one place
header_type: "hero"
header_img: "https://images.unsplash.com/photo-1545290614-5ceedf604139?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1200&q=60"
permalink: /demo
include_collection: demo
og_image: /assets/img/site/banner-demos.png
---

This is an example of how to create a index for a specific collection, in this case `demo`.

The front matter of this page is 

```yaml
---
layout: indexcategory
title: "Demos"
subtitle: All demos in one place
permalink: /demo
include_collection: demo
og_image: /assets/img/site/banner-demos.png
---
```
