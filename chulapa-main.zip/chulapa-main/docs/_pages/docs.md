---
layout: indexcategory
title: '<span class="chulapa">Chulapa</span> Documentation'
subtitle: Read the documentation
permalink: /docs
include_collection: docs
header_type: "hero"
header_img: "https://images.unsplash.com/photo-1545290614-5ceedf604139?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1200&q=60"
og_image: /assets/img/site/banner-docs.png
index_sort_asc: true
index_items: 20
---

<span class="chulapa">Chulapa</span> Jekyll Theme has an extensive documentation.

Read the docs to start with <span class="chulapa">Chulapa</span>, or use
the [Search](https://dieghernan.github.io/chulapa/search) of the site.


Have fun!
