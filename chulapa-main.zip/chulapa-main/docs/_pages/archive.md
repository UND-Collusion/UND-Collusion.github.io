---
layout: archive
title: Archive
subtitle: Blog entries
permalink: /archive
include_collection: posts
excerpt: News archive
show_breadcrumb  : true
breadcrumb_list :
  - label: Home
    url: /
  - label: Blog
    url: /blog/
---