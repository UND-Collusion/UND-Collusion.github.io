---
layout: archive
title: Archive
subtitle: All the content of this site by date
permalink: ./demo/archive
show_breadcrumb: true
breadcrumb_list:
  - label: Home
    url: /
  - label: Demo
    url: /demo
---

This page shows the content sorted by date. Note that `include_missdates` is not set, so only collection contents with dates would be included.


```
---
layout: archive
title: Archive
subtitle: All the content of this site by date
permalink: ./demo/archive
show_breadcrumb: true
breadcrumb_list:
  - label: Home
    url: /
  - label: Demo
    url: /demo
---

```
