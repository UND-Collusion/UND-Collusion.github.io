---
layout: cloudcategory
title: Categories
permalink: /categories
include_collection: posts
excerpt: Categories on Chulapa
show_breadcrumb   : true
breadcrumb_list :
  - label: Home
    url: /
  - label: Blog
    url: /blog/
---