---
title: Post header
categories: [demo]
header_type: post
tags: [layout-default,header-post, social-links, tags, categories, bottom-navs, author, date, random]
date: 2020-01-01
show_date         : true
show_sociallinks  : true
show_tags         : true
show_categories   : true
show_bottomnavs   : true
show_author: true
show_random: true
---

This page shows the `post` header with the default author set on your `_config` file. It also shows the date on top of the content.



```yaml
---
title: Post header
categories: [demo]
header_type: post
tags: [layout-default,header-post, image, social-links, tags, categories, bottom-navs, author, date]
date: 2020-02-03
show_date         : true
show_sociallinks  : true
show_tags         : true
show_categories   : true
show_bottomnavs   : true
show_author: true
show_random: true
---
```
