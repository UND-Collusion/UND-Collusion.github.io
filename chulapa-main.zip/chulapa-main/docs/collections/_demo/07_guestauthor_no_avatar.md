---
title: Guest author
subtitle: But no location or image
categories: [demo, author-guest]
header_type: base
tags: [layout-default,header-base, social-links, tags, categories, bottom-navs, date, comments,  author, author-guest, no-avatar, no-location]
date: 2020-03-01
show_date         : true
show_sociallinks  : true
show_tags         : true
show_categories   : true
show_bottomnavs   : true
show_comments     : true
show_author       : true
author:
  name: Octocat
  links:                
    - url: https://github.com/github/
      icon: "fab fa-github"
    - url: https://twitter.com/github
      icon: fab fa-twitter
    - url: https://github.com/facebook
      icon: "fab fa-facebook"
    - url: https://www.linkedin.com
      icon: "fab fa-linkedin"
    - url: fakeemail@github.com
      icon: far fa-envelope
project_links:
    - url: https://www.mathjax.org/
      icon: fas fa-superscript
      label: Go to MathJax.org
    - url: https://www.example.com
      icon: fab fa-github
      label: Example            
---
This page shows how a contributor could be added to your blog, but without an avatar or location. **Octocat** is shy today.



```yaml
---
title: Guest author
subtitle: But no location or image
categories: [demo, author-guest]
header_type: hero
tags: [layout-default,header-hero, social-links, tags, categories, bottom-navs, date, comments, author, author-guest, no-avatar, no-location, project-links ]
date: 2020-03-01
show_date         : true
show_sociallinks  : true
show_tags         : true
show_categories   : true
show_bottomnavs   : true
show_comments     : true
show_author       : true
author:
  name: Octocat
  links:                
    - url: https://github.com/github/
      icon: "fab fa-github"
    - url: https://twitter.com/github
      icon: fab fa-twitter
    - url: https://github.com/facebook
      icon: "fab fa-facebook"
    - url: https://www.linkedin.com
      icon: "fab fa-linkedin"
    - url: fakeemail@github.com
      icon: "far fa-envelope"
project_links:
    - url: https://www.mathjax.org/
      icon: fas fa-superscript
      label: Go to MathJax.org
    - url: https://www.example.com
      icon: fab fa-github
      label: Example
---
```
