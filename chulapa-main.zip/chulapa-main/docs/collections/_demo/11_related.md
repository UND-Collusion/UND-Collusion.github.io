---
title: Related
categories: [demo]
header_type: post
tags: [layout-default,header-post, social-links, tags, categories, bottom-navs, author, date, related]
date: 2022-12-01
show_date         : true
show_related  : true
show_sociallinks  : true
show_tags         : true
show_categories   : true
show_bottomnavs   : true
show_author: true
---

This page shows the `related` snippet. See how related pages appeared on the bottom.



```yaml
---
title: Related
categories: [demo]
header_type: post
tags: [layout-default,header-post, social-links, tags, categories, bottom-navs, author, date, related]
date: 2022-12-01
show_date         : true
show_related  : true
show_sociallinks  : true
show_tags         : true
show_categories   : true
show_bottomnavs   : true
show_author: true
---
```
