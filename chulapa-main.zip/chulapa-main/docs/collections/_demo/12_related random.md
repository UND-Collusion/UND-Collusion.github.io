---
title: Related and Random
categories: [demo]
header_type: post
tags: [layout-default,header-post, social-links, tags, categories, bottom-navs, author, date, related, random]
date: 2022-12-01
show_date         : true
show_related  : true
show_random  : true
related_label: '<h4>There are related posts</h4>'
random_label: '<h4>These are random, they will change on each build</h4>'
show_sociallinks  : true
show_tags         : true
show_categories   : true
show_bottomnavs   : true
show_author: true
---

This page shows the `related` and `random` snippet. See how both appeared on the bottom, although you may not use
both card types at the same time



```yaml
---
title: Related and Random
categories: [demo]
header_type: post
tags: [layout-default,header-post, social-links, tags, categories, bottom-navs, author, date, related, random]
date: 2022-12-01
show_date         : true
show_related  : true
show_random  : true
related_label: '<h4>There are related posts</h4>'
random_label: '<h4>These are random, they will change on each build</h4>'
show_sociallinks  : true
show_tags         : true
show_categories   : true
show_bottomnavs   : true
show_author: true
---
```
